from django.urls import path
from . import views

app_name = 'analysis'

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.upload_network, name='upload_network'),
    path('network/<int:network_id>/hydraulic/', views.hydraulic_analysis, name='hydraulic_analysis'),
    path('network/<int:network_id>/valves/', views.valve_optimization, name='valve_optimization'),
    path('network/<int:network_id>/mpc/', views.mpc_control, name='mpc_control'),
]