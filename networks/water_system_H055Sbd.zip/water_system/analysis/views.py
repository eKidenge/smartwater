from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import login
from .models import WaterNetwork, HydraulicAnalysis, ValveOptimization, MPCControl
from .forms import NetworkUploadForm, SignUpForm
import json
import tempfile
import os
from datetime import datetime
import numpy as np
import pandas as pd
import wntr

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('analysis:index')  # Updated to use namespace
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

def parse_epanet_file(file_path):
    """Parse EPANET .inp file and return network data using wntr."""
    try:
        wn = wntr.network.WaterNetworkModel(file_path)
        
        nodes = []
        for node_name, node_obj in wn.nodes():
            nodes.append({
                'id': node_name,
                'type': node_obj.node_type,
                'coordinates': node_obj.coordinates if hasattr(node_obj, 'coordinates') else None,
                'elevation': getattr(node_obj, 'elevation', None),
                'demand': getattr(node_obj, 'demand', None)
            })
        
        links = []
        for link_name, link_obj in wn.links():
            links.append({
                'id': link_name,
                'type': link_obj.link_type,
                'from_node': link_obj.start_node_name,
                'to_node': link_obj.end_node_name,
                'length': getattr(link_obj, 'length', None),
                'diameter': getattr(link_obj, 'diameter', None),
                'roughness': getattr(link_obj, 'roughness', None)
            })
        
        return {
            'nodes': nodes,
            'links': links,
            'node_count': len(nodes),
            'link_count': len(links),
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        raise ValueError(f"EPANET file parsing failed: {str(e)}")

def run_hydraulic_analysis(network):
    """Run hydraulic analysis on the water network."""
    try:
        with tempfile.NamedTemporaryFile(suffix='.inp', delete=False) as temp_file:
            for chunk in network.network_file.chunks():
                temp_file.write(chunk)
            temp_file_path = temp_file.name
        
        wn = wntr.network.WaterNetworkModel(temp_file_path)
        sim = wntr.sim.EpanetSimulator(wn)
        results = sim.run_sim()
        
        # Process results
        pressure_results = results.node['pressure']
        flow_results = results.link['flowrate']
        first_time = pressure_results.index[0]
        
        pressures = {
            node: pressure_results.loc[first_time, node]
            for node in wn.node_name_list
        }
        
        flows = {
            link: flow_results.loc[first_time, link]
            for link in wn.link_name_list
        }
        
        os.unlink(temp_file_path)
        
        return {
            'pressures': pressures,
            'flows': flows,
            'min_pressure': min(pressures.values()),
            'max_pressure': max(pressures.values()),
            'avg_pressure': sum(pressures.values()) / len(pressures),
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
            os.unlink(temp_file_path)
        raise RuntimeError(f"Hydraulic analysis failed: {str(e)}")

@login_required
def index(request):
    water_networks = WaterNetwork.objects.filter(user=request.user).order_by('-created_at')
    context = {
        'water_networks': water_networks,
        'has_networks': water_networks.exists()  # Explicit boolean
    }
    return render(request, 'analysis/index.html', context)

@login_required
def upload_network(request):
    if request.method == 'POST':
        form = NetworkUploadForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                network_data = parse_epanet_file(form.cleaned_data['network_file'].temporary_file_path())
                
                network = WaterNetwork(
                    user=request.user,
                    name=form.cleaned_data['name'],
                    description=form.cleaned_data['description'],
                    network_file=form.cleaned_data['network_file'],
                    file_type='INP',
                    network_data=network_data
                )
                network.save()
                
                messages.success(request, 'Network uploaded successfully!')
                return redirect('analysis:hydraulic_analysis', network_id=network.id)
            except Exception as e:
                messages.error(request, f'Error processing network file: {str(e)}')
    else:
        form = NetworkUploadForm()
    
    return render(request, 'analysis/upload_network.html', {'form': form})

@login_required
def hydraulic_analysis(request, network_id):
    try:
        network = WaterNetwork.objects.get(id=network_id, user=request.user)
        
        if request.method == 'POST':
            try:
                analysis_results = run_hydraulic_analysis(network)
                
                HydraulicAnalysis.objects.create(
                    network=network,
                    parameters={},
                    results=analysis_results
                )
                
                # Prepare visualization data
                pressure_values = list(analysis_results['pressures'].values())
                pressure_ranges = {
                    'low': sum(1 for p in pressure_values if p < 20),
                    'normal': sum(1 for p in pressure_values if 20 <= p <= 30),
                    'high': sum(1 for p in pressure_values if p > 30)
                }
                
                context = {
                    'network': network,
                    'results': analysis_results,
                    'pressure_ranges': pressure_ranges,
                    'pressure_data': json.dumps({
                        'labels': list(analysis_results['pressures'].keys()),
                        'values': pressure_values
                    })
                }
                return render(request, 'analysis/hydraulic_results.html', context)
            
            except Exception as e:
                messages.error(request, f"Analysis failed: {str(e)}")
                return redirect('analysis:hydraulic_analysis', network_id=network.id)
        
        # GET request - show analysis form
        return render(request, 'analysis/hydraulic_analysis.html', {
            'network': network,
            'network_json': json.dumps(network.network_data)
        })
    
    except WaterNetwork.DoesNotExist:
        messages.error(request, "Network not found or access denied")
        return redirect('analysis:index')

@login_required
def valve_optimization(request, network_id):
    try:
        network = WaterNetwork.objects.get(id=network_id, user=request.user)
        
        # Get existing optimization results
        optimizations = {
            'GA': ValveOptimization.objects.filter(network=network, algorithm='GA').last(),
            'PSO': ValveOptimization.objects.filter(network=network, algorithm='PSO').last(),
            'AEO': ValveOptimization.objects.filter(network=network, algorithm='AEO').last()
        }
        
        if request.method == 'POST':
            algorithm = request.POST.get('algorithm', 'GA').upper()
            parameters = {
                'population_size': int(request.POST.get('population_size', 50)),
                'max_iterations': int(request.POST.get('max_iterations', 100)),
                'pressure_target': float(request.POST.get('pressure_target', 30.0))
            }
            
            # Run optimization (simplified for example)
            optimization_results = {
                'valve_locations': [f"Node-{i}" for i in range(1, 6)],
                'pressure_reduction': round(np.random.uniform(5.0, 15.0), 2),
                'computation_time': round(np.random.uniform(10.0, 30.0), 2),
                'parameters': parameters
            }
            
            # Save results
            optimization = ValveOptimization.objects.create(
                network=network,
                algorithm=algorithm,
                parameters=parameters,
                results=optimization_results
            )
            optimizations[algorithm] = optimization
            
            messages.success(request, f"{algorithm} optimization completed!")
        
        # Prepare context
        context = {
            'network': network,
            'optimizations': optimizations,
            'selected_algorithm': request.GET.get('algorithm', 'GA').upper(),
            'network_json': json.dumps(network.network_data)
        }
        
        return render(request, 'analysis/valve_optimization.html', context)
    
    except WaterNetwork.DoesNotExist:
        messages.error(request, "Network not found or access denied")
        return redirect('analysis:index')

@login_required
def mpc_control(request, network_id):
    try:
        network = WaterNetwork.objects.get(id=network_id, user=request.user)
        
        # Get latest valve optimization results
        valve_optimization = ValveOptimization.objects.filter(
            network=network
        ).order_by('-created_at').first()
        
        if not valve_optimization:
            messages.warning(request, "Please run valve optimization first")
            return redirect('analysis:valve_optimization', network_id=network.id)
        
        valve_locations = valve_optimization.results.get('valve_locations', [])
        
        if request.method == 'POST':
            parameters = {
                'time_horizon': int(request.POST.get('time_horizon', 24)),
                'time_step': int(request.POST.get('time_step', 15)),
                'max_adjustment': float(request.POST.get('max_adjustment', 10.0))
            }
            
            # Run MPC simulation (simplified)
            mpc_results = {
                'pressure_profile': [round(30 + 5 * np.sin(i/10), 2) for i in range(24)],
                'valve_adjustments': [
                    {
                        'time': f"{i}:00",
                        'valve': np.random.choice(valve_locations),
                        'adjustment': round(np.random.uniform(-5.0, 5.0), 2)
                    } for i in range(0, 24, 2)
                ],
                'energy_savings': round(np.random.uniform(5.0, 15.0), 2),
                'parameters': parameters
            }
            
            # Save results
            MPCControl.objects.create(
                network=network,
                valve_locations=valve_locations,
                parameters=parameters,
                results=mpc_results
            )
            
            messages.success(request, "MPC simulation completed!")
            return redirect('analysis:mpc_control', network_id=network.id)
        
        # GET request - show MPC form
        mpc_results = MPCControl.objects.filter(network=network).order_by('-created_at').first()
        
        context = {
            'network': network,
            'valve_locations': valve_locations,
            'mpc_results': mpc_results.results if mpc_results else None,
            'network_json': json.dumps(network.network_data)
        }
        
        return render(request, 'analysis/mpc_control.html', context)
    
    except WaterNetwork.DoesNotExist:
        messages.error(request, "Network not found or access denied")
        return redirect('analysis:index')