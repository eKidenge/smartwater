from django.db import models
from django.contrib.auth.models import User
from django.core.serializers.json import DjangoJSONEncoder

class WaterNetwork(models.Model):
    FILE_TYPE_CHOICES = [
        ('INP', 'EPANET .inp file'),
        ('JSON', 'JSON format'),
        ('DAT', 'Data file'),
    ]
    
    name = models.CharField(max_length=100, verbose_name="Network Name")
    description = models.TextField(blank=True, null=True, verbose_name="Description")
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='water_networks',
        verbose_name="Owner"
    )
    network_file = models.FileField(
        upload_to='water_networks/%Y/%m/%d/',
        verbose_name="Network File"
    )
    file_type = models.CharField(
        max_length=10,
        choices=FILE_TYPE_CHOICES,
        default='INP',
        verbose_name="File Type"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")
    network_data = models.JSONField(
        encoder=DjangoJSONEncoder,
        null=True,
        blank=True,
        verbose_name="Network Data"
    )
    
    class Meta:
        verbose_name = "Water Network"
        verbose_name_plural = "Water Networks"
        ordering = ['-created_at']
        unique_together = ['user', 'name']  # Prevent duplicate names per user
    
    def __str__(self):
        return f"{self.name} ({self.file_type})"

class HydraulicAnalysis(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('RUNNING', 'Running'),
        ('COMPLETED', 'Completed'),
        ('FAILED', 'Failed'),
    ]
    
    network = models.ForeignKey(
        WaterNetwork,
        on_delete=models.CASCADE,
        related_name='hydraulic_analyses',
        verbose_name="Water Network"
    )
    parameters = models.JSONField(
        encoder=DjangoJSONEncoder,
        default=dict,
        verbose_name="Analysis Parameters"
    )
    results = models.JSONField(
        encoder=DjangoJSONEncoder,
        null=True,
        blank=True,
        verbose_name="Analysis Results"
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='PENDING',
        verbose_name="Analysis Status"
    )
    started_at = models.DateTimeField(auto_now_add=True, verbose_name="Started At")
    completed_at = models.DateTimeField(null=True, blank=True, verbose_name="Completed At")
    log = models.TextField(blank=True, verbose_name="Analysis Log")
    
    class Meta:
        verbose_name = "Hydraulic Analysis"
        verbose_name_plural = "Hydraulic Analyses"
        ordering = ['-started_at']
    
    def __str__(self):
        return f"Analysis #{self.id} for {self.network.name}"

class ValveOptimization(models.Model):
    ALGORITHM_CHOICES = [
        ('GA', 'Genetic Algorithm'),
        ('PSO', 'Particle Swarm Optimization'),
        ('AEO', 'Artificial Ecosystem Optimization'),
        ('HYBRID', 'Hybrid Algorithm'),
    ]
    
    network = models.ForeignKey(
        WaterNetwork,
        on_delete=models.CASCADE,
        related_name='valve_optimizations',
        verbose_name="Water Network"
    )
    algorithm = models.CharField(
        max_length=10,
        choices=ALGORITHM_CHOICES,
        verbose_name="Optimization Algorithm"
    )
    parameters = models.JSONField(
        encoder=DjangoJSONEncoder,
        default=dict,
        verbose_name="Algorithm Parameters"
    )
    results = models.JSONField(
        encoder=DjangoJSONEncoder,
        null=True,
        blank=True,
        verbose_name="Optimization Results"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    computation_time = models.FloatField(
        null=True,
        blank=True,
        verbose_name="Computation Time (seconds)"
    )
    
    class Meta:
        verbose_name = "Valve Optimization"
        verbose_name_plural = "Valve Optimizations"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.get_algorithm_display()} Optimization for {self.network.name}"

class MPCControl(models.Model):
    network = models.ForeignKey(
        WaterNetwork,
        on_delete=models.CASCADE,
        related_name='mpc_controls',
        verbose_name="Water Network"
    )
    valve_locations = models.JSONField(
        encoder=DjangoJSONEncoder,
        verbose_name="Valve Locations"
    )
    control_parameters = models.JSONField(
        encoder=DjangoJSONEncoder,
        default=dict,
        verbose_name="Control Parameters"
    )
    simulation_results = models.JSONField(
        encoder=DjangoJSONEncoder,
        null=True,
        blank=True,
        verbose_name="Simulation Results"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    time_horizon = models.PositiveIntegerField(
        default=24,
        verbose_name="Time Horizon (hours)"
    )
    
    class Meta:
        verbose_name = "MPC Control"
        verbose_name_plural = "MPC Controls"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"MPC Control for {self.network.name}"